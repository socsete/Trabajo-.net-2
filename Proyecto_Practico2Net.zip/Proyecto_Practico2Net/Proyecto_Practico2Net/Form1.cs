﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Proyecto_Practico2Net {
    public partial class Form1 : Form {
        String cadena;
        int contPalabras = 0;
        int contEspacios = 0;
        int contTabs = 0;
        int contLineas = 0;
        int contVocales = 0;
        int contConsonantes = 0;

        public Form1() {
            InitializeComponent();
            cboQuitar.Items.Add("Espacios en Blanco");
            cboQuitar.Items.Add("Vocales");
            cboQuitar.Items.Add("Consonantes");

        }

        private void btnGuardar_Click(object sender, EventArgs e) {
            SaveFileDialog save = new SaveFileDialog();
            save.Filter = "documento de texto|*.txt";
            save.Title = "Guardar RichTextBox";
            save.FileName = "Sin titulo";

            var resultado = save.ShowDialog();

            if (resultado == DialogResult.OK) {
                StreamWriter escribir = new StreamWriter(save.FileName);
                foreach (object linea in richTextBox1.Lines) {

                    escribir.WriteLine(linea);

                }
                escribir.Close();

            }



        }

        private void btnExaminar_Click(object sender, EventArgs e) {

            String rutaArchivo = string.Empty;

            OpenFileDialog abrir = new OpenFileDialog();
            abrir.Filter = "documento de texto|*.txt";
            abrir.Title = "Abrir....";
            abrir.FileName = "Sin titulo";

            var resultado = abrir.ShowDialog();


            if (resultado == DialogResult.OK) {

                StreamReader leer = new StreamReader(abrir.FileName);

                richTextBox1.Text = leer.ReadToEnd();
                leer.Close();

                rutaArchivo = abrir.FileName;
            }

            txtRuta.Text = rutaArchivo;
            this.richTextBox1.Enabled = true;
            this.richTextBox1.ReadOnly = true;



            cadena = richTextBox1.Text;
            lblCaracteres.Text = "" + richTextBox1.TextLength;


            for (int i = 0; i < cadena.Length; i++) {
                if (cadena[i] == 'a' || cadena[i] == 'e' || cadena[i] == 'i' || cadena[i] == 'o' || cadena[i] == 'u') {
                    contVocales++;
                } else if (cadena[i] == 'b' || cadena[i] == 'c' || cadena[i] == 'd' ||
                    cadena[i] == 'f' || cadena[i] == 'g' ||
                    cadena[i] == 'h' || cadena[i] == 'j' ||
                    cadena[i] == 'k' || cadena[i] == 'l' ||
                    cadena[i] == 'm' || cadena[i] == 'p' ||
                    cadena[i] == 'q' || cadena[i] == 'r' ||
                    cadena[i] == 's' || cadena[i] == 't' ||
                    cadena[i] == 'v' || cadena[i] == 'w' ||
                    cadena[i] == 'x' || cadena[i] == 'y' ||
                    cadena[i] == 'z') {
                    contConsonantes++;

                }
                if (cadena[i] == ' ') {
                    contEspacios++;
                }

                if (cadena[i] == ' ' || cadena[i] == '.') {
                    contPalabras++;
                }

                if (cadena[i] == '\t') {
                    contTabs++;
                }
                if (cadena[i] == '\n') {
                    contLineas++;
                }

            }


            lblTab.Text = contTabs.ToString();
            lblLinea.Text = contLineas.ToString();
            lblVocales.Text = contVocales.ToString();
            lblPalabras.Text = contPalabras.ToString();
            lblEspacios.Text = contEspacios.ToString();
            lblConsonantes.Text = contConsonantes.ToString();

        }

        private void btnProcesar_Click(object sender, EventArgs e) {
            foreach (String item in cboQuitar.Items) {
                if (item.Equals("Espacios en Blanco")) {
                    richTextBox1.Text = cadena.Replace(" ", "");
                }else if (item.Equals("Vocales")) {
                    richTextBox1.Text = cadena.Replace("a", "").Replace("e", "").Replace("i", "").Replace("o", "").Replace("u", "");

                }else if (item.Equals("Consonantes")) {
                    richTextBox1.Text = cadena.Replace("b", "")
                        .Replace("c", "")
                        .Replace("d", "")
                        .Replace("f", "")
                        .Replace("g", "")
                        .Replace("h", "")
                        .Replace("j", "")
                        .Replace("k", "")
                        .Replace("l", "")
                        .Replace("m", "")
                        .Replace("n", "")
                        .Replace("p", "")
                        .Replace("q", "")
                        .Replace("r", "")
                        .Replace("s", "")
                        .Replace("t", "")
                        .Replace("v", "")
                        .Replace("w", "")
                        .Replace("x", "")
                        .Replace("y", "")
                        .Replace("z","");
                }

            }
        }
    }
}


